import React, { useState } from 'react';
import axios from 'axios';

function App() {
  const [image, setImage] = useState(null);
  const [productName, setProductName] = useState('');
  const [script, setScript] = useState('');
  const [voiceUrl, setVoiceUrl] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const API = process.env.REACT_APP_API_BASE_URL || 'http://localhost:3000/api';

  const handleGenerateScript = async () => {
    setLoading(true);
    const res = await axios.post(`${API}/generate-script`, {
      productName, tone: 'casual', lengthSeconds: 20
    });
    setScript(res.data.script);
    setLoading(false);
  };

  const handleGenerateVoice = async () => {
    setLoading(true);
    const res = await axios.post(`${API}/generate-voice`, { script, voice: 'Natural Female' });
    setVoiceUrl(res.data.audioUrl);
    setLoading(false);
  };

  const handleComposeVideo = async () => {
    setLoading(true);
    const formData = new FormData();
    formData.append('image', image);
    formData.append('productName', productName);
    const varRes = await axios.post(`${API}/generate-variations`, formData);
    const variations = varRes.data.variations;

    const compRes = await axios.post(`${API}/compose-video`, { images: variations, audioUrl: voiceUrl, script });
    setVideoUrl(compRes.data.videoUrl);
    setLoading(false);
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial' }}>
      <h2>TikTok AI Content Generator</h2>
      <input type="text" placeholder="Nama Produk" value={productName} onChange={e => setProductName(e.target.value)} />
      <br/><br/>
      <input type="file" accept="image/*" onChange={e => setImage(e.target.files[0])} />
      <br/><br/>
      <button onClick={handleGenerateScript} disabled={loading}>Generate Script</button>
      {script && <p><b>Script:</b> {script}</p>}
      <br/>
      {script && <button onClick={handleGenerateVoice} disabled={loading}>Generate Voice</button>}
      {voiceUrl && <audio controls src={voiceUrl}></audio>}
      <br/>
      {voiceUrl && <button onClick={handleComposeVideo} disabled={loading}>Compose Video</button>}
      {videoUrl && <div><video controls src={videoUrl} width="300" /></div>}
    </div>
  );
}

export default App;
