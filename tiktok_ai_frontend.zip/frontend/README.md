# TikTok AI Content Generator - Frontend

## Setup
```bash
cd frontend
npm install
cp .env.example .env
npm start
```

## Config
- Edit `.env` → `REACT_APP_API_BASE_URL` sesuaikan dengan URL backend Anda (misal http://localhost:3000/api atau Railway API).
